package com.capgemini.Test;

import static org.testng.Assert.assertEquals;

import com.capgemini.TestBase;
import com.capgemini.pages.LoginPage;
import com.capgemini.pages.Project;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginPageStepDef extends TestBase {
	static LoginPage login;
	
	
	
	public LoginPageStepDef() {
		super();
		setup();
	}

	private void setup() {
	initialization();

		
	}

	@Given("^Login Page is opening$")
	public void login_Page_is_opening() throws Throwable {
	   
	  
	}

	@When("^Login Page is open$")
	public void login_Page_is_open() throws Throwable {
	 
	}

	@Then("^Title of page is (.*)$")
	public void title_of_page_is_project(String Login) throws Throwable {
		login=new LoginPage();
		assertEquals(Login, login.getTitle());
		driver.quit();
	   
	}

}
