package com.capgemini;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestBase {
	public static WebDriver driver;
	
	public static void initialization()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\SHJADAUN\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.get("C:\\Users\\SHJADAUN\\Downloads\\BDD-LOGIN-HTML-PAGE-master\\BDD-LOGIN-HTML-PAGE-master\\login1.html");
	}

}
