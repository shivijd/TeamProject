package com.capgemini.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.capgemini.TestBase;

public class Resitered extends TestBase{
	@FindBy(xpath="/html/body/h1")
	WebElement h1;
	
	
	public Resitered()
	{
		PageFactory.initElements(driver, this);
	}
	public String getHeading()
	{
		System.out.println(h1.getText());
		return h1.getText();
	}

}
